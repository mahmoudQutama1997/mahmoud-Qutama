function show(){
    var InputText=document.querySelector('.searchfield').value;
    
    alert("you have serached for the " +InputText)
}
function heart(){
    var number=document.querySelector(' .zero')
    var  likedtext=number.innerText;
    likesintegarvalue=parseInt(likedtext)+1;
   number.innerText=likesintegarvalue;
}
function remove(){
    var btn=document.querySelector('.btn-watch');
    btn.remove();
}
